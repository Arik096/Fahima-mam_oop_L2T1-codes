#include<iostream>
using namespace std;

int main()
{
    int a;
    float x;
    char st[20];

    cin>>a;
    cin>>x;
    cin>>st;

    cout<<a<< endl;
    cout<<x<< endl;
    cout<<st<< endl;

    return 0;
}
