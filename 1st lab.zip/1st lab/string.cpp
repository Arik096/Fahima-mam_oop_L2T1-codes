#include<iostream>
using namespace std;
int main()
{
    char stringArray[100];
    cin.getline(stringArray,100);
    cout<<stringArray<<endl;
    return 0;
}
