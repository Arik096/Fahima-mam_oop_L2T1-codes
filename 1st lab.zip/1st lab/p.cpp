#include<iostream>
using namespace std;
int main()
{

    int a;
    float b;
    char c[20];

    cin>>a;
    cin>>b;
    cin>>c;

    cout<<a;
    cout<<"\n";
    cout<<b;
    cout<<"\n";
    cout<<c;
    cout<<"\n";
    return 0;
}
