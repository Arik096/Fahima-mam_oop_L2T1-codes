#include<iostream>
using namespace std;
#include<iomanip>
int main()
{

    float a;
    cin>>a;
    cout<<setprecision(4)<<a;
    return 0;

}

